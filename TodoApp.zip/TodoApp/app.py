from flask import Flask, render_template, redirect, sessions, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import  FlaskForm, form
from wtforms import StringField, SubmitField
from wtforms.validators import InputRequired, Length


app = Flask(__name__)
db = SQLAlchemy(app)
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///database.db"
app.config['SECRET_KEY'] = '24de83409a724440943d829d99f02abe'

class TodoForm(FlaskForm): 
    todo = StringField('Enter todo', validators=[InputRequired(), Length(min=2, max=50)])
    submit = SubmitField('Add Todo')

class Todo(db.Model):
    id = db.Column(db.Integer, primary_key =True)
    todo = db.Column(db.String(50), nullable = False)
    

@app.route('/', methods=['GET', "POST"])
def home():
    form = TodoForm()
    todos = Todo.query.all()
    if form.validate_on_submit():
     new_todo = Todo(todo= form.todo.data)
     db.session.add(new_todo)
     db.session.commit()
     return redirect(url_for('home'))
    return render_template('home.html', form=form, todos=todos)

@app.route('/deletetodo/<int:todo_id>', methods=['GET', "POST"])
def deletetodo(todo_id):
    todo = Todo.query.get_or_404(todo_id)
    db.session.delete(todo)
    db.session.commit()
    return redirect(url_for('home'))

if __name__ == "__main__":
    app.run(debug=True)